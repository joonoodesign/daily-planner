import flet as ft
import uuid
from datetime import datetime, timedelta, date

def main(page: ft.Page):
    page.title = "채원이를 위한 데일리 타임라인"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.scroll = ft.ScrollMode.AUTO 
    page.bgcolor = "#E9ECEF"  
    page.window.width = 1100
    page.window.height = 800
    page.padding = 20

    editing_state = {"id": None}

    # ----------------------------------------------------
    # [웹 브라우저 내부 저장소 연동 함수] - json 파일 대신 사용
    # ----------------------------------------------------
    def load_tasks():
        tasks = page.client_storage.get("tasks")
        if not tasks:
            return []
            
        modified = False
        today_str = date.today().strftime("%Y-%m-%d")
        for task in tasks:
            if "id" not in task: task["id"] = str(uuid.uuid4()); modified = True
            if "date" not in task: task["date"] = today_str; modified = True
            if "completed" not in task: task["completed"] = False; modified = True
                
        if modified:
            save_tasks(tasks)
        return tasks

    def save_tasks(tasks):
        page.client_storage.set("tasks", tasks)

    def load_memo():
        return page.client_storage.get("memo") or ""

    def save_memo(text):
        page.client_storage.set("memo", text)

    # ----------------------------------------------------
    # [입력 폼 UI 구성]
    # ----------------------------------------------------
    hours_options = [ft.dropdown.Option(str(i)) for i in range(1, 13)]
    minutes_options = [ft.dropdown.Option(str(i*10).zfill(2)) for i in range(6)]

    date_dropdown = ft.Dropdown(options=[ft.dropdown.Option("어제"), ft.dropdown.Option("오늘"), ft.dropdown.Option("내일")], value="오늘", width=100, text_size=14, content_padding=10)
    start_ampm = ft.Dropdown(options=[ft.dropdown.Option("오전"), ft.dropdown.Option("오후")], value="오전", width=95, text_size=14, content_padding=10)
    start_hr = ft.Dropdown(options=hours_options, value="9", width=90, text_size=14, content_padding=10)
    start_min = ft.Dropdown(options=minutes_options, value="00", width=90, text_size=14, content_padding=10)
    end_ampm = ft.Dropdown(options=[ft.dropdown.Option("오전"), ft.dropdown.Option("오후")], value="오후", width=95, text_size=14, content_padding=10)
    end_hr = ft.Dropdown(options=hours_options, value="1", width=90, text_size=14, content_padding=10)
    end_min = ft.Dropdown(options=minutes_options, value="00", width=90, text_size=14, content_padding=10)
    title_input = ft.TextField(label="어떤 일정인가요?", expand=True)

    action_btn_text = ft.Text("일정 추가하기", color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD)
    cancel_btn_text = ft.Text("수정 취소", color=ft.Colors.GREY_700, weight=ft.FontWeight.BOLD)

    def reset_form():
        editing_state["id"] = None
        date_dropdown.value = "오늘"
        start_ampm.value = "오전"
        start_hr.value = "9"
        start_min.value = "00"
        end_ampm.value = "오후"
        end_hr.value = "1"
        end_min.value = "00"
        title_input.value = ""
        
        action_btn_text.value = "일정 추가하기"
        action_btn_bg.bgcolor = ft.Colors.BLUE_600
        cancel_btn_bg.visible = False
        page.update()

    def process_task(e):
        if not title_input.value:
            return
            
        def convert_to_float(ampm, h_str, m_str):
            h = int(h_str)
            m = int(m_str)
            if ampm == "오전" and h == 12: h = 0
            elif ampm == "오후" and h != 12: h += 12
            return h + (m / 60.0)

        st = convert_to_float(start_ampm.value, start_hr.value, start_min.value)
        et = convert_to_float(end_ampm.value, end_hr.value, end_min.value)
        
        today = date.today()
        if date_dropdown.value == "어제": target_date = today - timedelta(days=1)
        elif date_dropdown.value == "내일": target_date = today + timedelta(days=1)
        else: target_date = today
            
        current_tasks = load_tasks()
        
        if editing_state["id"]:
            for t in current_tasks:
                if t["id"] == editing_state["id"]:
                    t["date"] = target_date.strftime("%Y-%m-%d")
                    t["start"] = st
                    t["end"] = et
                    t["title"] = title_input.value
                    break
        else:
            current_tasks.append({
                "id": str(uuid.uuid4()), 
                "date": target_date.strftime("%Y-%m-%d"),
                "start": st,
                "end": et,
                "title": title_input.value,
                "completed": False
            })
        
        save_tasks(current_tasks)
        reset_form()
        update_ui()

    action_btn_bg = ft.Container(content=action_btn_text, bgcolor=ft.Colors.BLUE_600, padding=15, border_radius=8, on_click=process_task)
    cancel_btn_bg = ft.Container(content=cancel_btn_text, bgcolor=ft.Colors.GREY_300, padding=15, border_radius=8, on_click=lambda e: reset_form(), visible=False)

    # ----------------------------------------------------
    # [타임라인 시각화 및 하단 리스트 영역]
    # ----------------------------------------------------
    timeline_stack = ft.Stack(width=4320, height=350)
    scrollable_timeline = ft.Column(
        controls=[ft.Row(controls=[timeline_stack], scroll=ft.ScrollMode.ALWAYS, expand=True)],
        height=400, scroll=ft.ScrollMode.ALWAYS 
    )
    task_list_column = ft.Column(spacing=10)

    def update_ui():
        timeline_stack.controls.clear()
        
        now = datetime.now()
        today = now.date()
        base_date = today - timedelta(days=1)
        
        grid_row = ft.Row(spacing=0)
        for i in range(72):
            hour = i % 24
            target_date = base_date + timedelta(days=(i // 24))
            
            if hour == 0:
                date_str = target_date.strftime("%m/%d")
                day_label = "어제" if i==0 else ("오늘" if i==24 else "내일")
                line_color = ft.Colors.BLUE_400
                header_text = f"{date_str} ({day_label})"
                weight = ft.FontWeight.BOLD
                text_color = ft.Colors.BLUE_800
            else:
                line_color = ft.Colors.GREY_300
                header_text = f"{hour}:00"
                weight = ft.FontWeight.NORMAL
                text_color = ft.Colors.GREY_500

            grid_row.controls.append(
                ft.Container(
                    width=60, height=3000,
                    content=ft.Row(
                        spacing=0,
                        controls=[
                            ft.Container(width=1 if hour != 0 else 2, height=3000, bgcolor=line_color),
                            ft.Container(content=ft.Text(header_text, size=11, color=text_color, weight=weight), padding=4)
                        ]
                    )
                )
            )
        timeline_stack.controls.append(grid_row)

        current_tasks = load_tasks()
        y_offset = 40 
        
        def format_time(time_float):
            h = int(time_float)
            m = int((time_float - h) * 60)
            ampm = "오전" if h < 12 else "오후"
            disp_h = h if h <= 12 else h - 12
            if disp_h == 0: disp_h = 12
            return f"{ampm} {disp_h}:{m:02d}"
        
        for task in current_tasks:
            try: task_date = datetime.strptime(task["date"], "%Y-%m-%d").date()
            except: task_date = today
                
            start = float(task["start"])
            end = float(task["end"])
            
            days_diff = (task_date - base_date).days
            if days_diff < 0 or days_diff > 2: continue 
                
            end_hours = int(end)
            end_mins = int((end - end_hours) * 60)
            if end_hours == 24: task_end_datetime = datetime.combine(task_date + timedelta(days=1), datetime.min.time())
            else: task_end_datetime = datetime.combine(task_date, datetime.min.time()) + timedelta(hours=end_hours, minutes=end_mins)

            is_completed = task.get("completed", False)
            is_overdue = (not is_completed) and (now > task_end_datetime)

            if is_completed: bg_color = "#E8F5E9"; text_color = "#2E7D32"
            elif is_overdue: bg_color = "#FFEBEE"; text_color = "#C62828"
            else: bg_color = "#E3F2FD"; text_color = "#1565C0"

            offset_hours = (days_diff * 24) + start
            left_pos = offset_hours * 60
            block_width = (end - start) * 60
            
            def make_edit_action(t):
                def pull_to_top_form(e):
                    def float_to_parts(f_val):
                        h = int(f_val)
                        m = int(round((f_val - h) * 60))
                        if m == 60: h += 1; m = 0
                        ampm = "오전" if (h % 24) < 12 else "오후"
                        disp_h = h % 12
                        if disp_h == 0: disp_h = 12
                        return ampm, str(disp_h), str(m).zfill(2)

                    s_ampm, s_h, s_m = float_to_parts(float(t["start"]))
                    e_ampm, e_h, e_m = float_to_parts(float(t["end"]))

                    try: t_date = datetime.strptime(t["date"], "%Y-%m-%d").date()
                    except: t_date = date.today()
                    
                    diff = (t_date - date.today()).days
                    if diff == -1: date_dropdown.value = "어제"
                    elif diff == 1: date_dropdown.value = "내일"
                    else: date_dropdown.value = "오늘"

                    start_ampm.value = s_ampm
                    start_hr.value = s_h
                    start_min.value = s_m
                    end_ampm.value = e_ampm
                    end_hr.value = e_h
                    end_min.value = e_m
                    title_input.value = t["title"]

                    editing_state["id"] = t["id"]
                    action_btn_text.value = "수정 완료하기"
                    action_btn_bg.bgcolor = ft.Colors.ORANGE_600 
                    cancel_btn_bg.visible = True
                    page.update()
                return pull_to_top_form
            
            timeline_stack.controls.append(
                ft.Container(
                    left=left_pos, top=y_offset, width=block_width, height=45, 
                    bgcolor=bg_color, border_radius=8, padding=6,
                    on_click=make_edit_action(task), 
                    tooltip="클릭하면 상단에서 수정할 수 있습니다.", 
                    content=ft.Column(
                        controls=[
                            ft.Text(f"{format_time(start)} - {format_time(end)}", size=10, color=text_color, weight=ft.FontWeight.BOLD),
                            ft.Text(task["title"], size=13, weight=ft.FontWeight.BOLD, color=text_color, overflow=ft.TextOverflow.ELLIPSIS, max_lines=1)
                        ],
                        spacing=0 
                    )
                )
            )
            y_offset += 55 

        timeline_stack.height = max(400, y_offset + 50)
        
        days_diff_now = (now.date() - base_date).days
        if 0 <= days_diff_now <= 2:
            current_float_time = now.hour + (now.minute / 60.0)
            red_line_offset = (days_diff_now * 24) + current_float_time
            red_line_pos = red_line_offset * 60
            
            timeline_stack.controls.append(ft.Container(left=red_line_pos, top=0, width=2, height=timeline_stack.height, bgcolor=ft.Colors.RED_600))
            timeline_stack.controls.append(ft.Container(left=red_line_pos - 12, top=10, bgcolor=ft.Colors.RED_600, border_radius=4, padding=4, content=ft.Text("현재", color=ft.Colors.WHITE, size=10, weight=ft.FontWeight.BOLD)))
        
        task_list_column.controls.clear()
        sorted_tasks = sorted(current_tasks, key=lambda x: (x.get("date", ""), float(x["start"])))
        
        for task in sorted_tasks:
            def make_delete_action(task_id):
                def delete_action(e):
                    if editing_state["id"] == task_id: reset_form()
                    tasks = load_tasks()
                    new_tasks = [t for t in tasks if t["id"] != task_id]
                    save_tasks(new_tasks)
                    update_ui()
                return delete_action

            def make_checkbox_action(task_id):
                def checkbox_action(e):
                    tasks = load_tasks()
                    for t in tasks:
                        if t["id"] == task_id: t["completed"] = e.control.value
                    save_tasks(tasks)
                    update_ui()
                return checkbox_action

            date_display = task.get("date", "")
            is_checked = task.get("completed", False)

            task_list_column.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Checkbox(value=is_checked, on_change=make_checkbox_action(task["id"]), fill_color=ft.Colors.GREEN_600 if is_checked else None, check_color=ft.Colors.WHITE),
                        ft.Text(date_display, weight=ft.FontWeight.BOLD, color=ft.Colors.GREY_600, width=90),
                        ft.Text(f"{format_time(task['start'])} ~ {format_time(task['end'])}", weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE_700, width=150),
                        ft.Text(
                            value="" if is_checked else task['title'], 
                            expand=True, size=15, 
                            color=ft.Colors.GREY_400 if is_checked else ft.Colors.BLACK, 
                            spans=[ft.TextSpan(task['title'], style=ft.TextStyle(decoration=ft.TextDecoration.LINE_THROUGH))] if is_checked else None
                        ),
                        ft.Container(content=ft.Text("삭제", color=ft.Colors.RED_500, weight=ft.FontWeight.BOLD), bgcolor="#FFEBEE", padding=10, border_radius=6, on_click=make_delete_action(task["id"]))
                    ]),
                    padding=15, bgcolor=ft.Colors.WHITE, border_radius=10
                )
            )
            
        page.update()

    # ----------------------------------------------------
    # [메모장 컴포넌트 구성]
    # ----------------------------------------------------
    def clear_memo(e):
        memo_input.value = ""
        save_memo("")
        page.update()

    memo_input = ft.TextField(
        value=load_memo(),
        multiline=True,
        min_lines=6, max_lines=12, expand=True, border_color=ft.Colors.GREY_300,
        hint_text="오늘 하루 떠오르는 아이디어나 잊지 말아야 할 메모를 자유롭게 남겨보세요. (자동 저장됩니다)",
        on_change=lambda e: save_memo(e.control.value) 
    )

    clear_memo_btn = ft.Container(
        content=ft.Text("메모장 지우기", color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD, size=12),
        bgcolor=ft.Colors.GREY_500, padding=10, border_radius=8, on_click=clear_memo
    )

    # ----------------------------------------------------
    # [전체 레이아웃 결합]
    # ----------------------------------------------------
    header_section = ft.Container(content=ft.Row([ft.Text("✨", size=28), ft.Text("데일리 타임라인 플래너", size=24, weight=ft.FontWeight.W_800, color="#1A1A1A")]), padding=10)
    input_section = ft.Container(
        content=ft.Column([
            ft.Row([
                ft.Text("날짜:", weight=ft.FontWeight.BOLD), date_dropdown,
                ft.Text("  |  시작:", weight=ft.FontWeight.BOLD), start_ampm, start_hr, ft.Text("시"), start_min, ft.Text("분"),
                ft.Text("   ~   ", weight=ft.FontWeight.BOLD),
                ft.Text("종료:", weight=ft.FontWeight.BOLD), end_ampm, end_hr, ft.Text("시"), end_min, ft.Text("분")
            ]),
            ft.Row([title_input, action_btn_bg, cancel_btn_bg])
        ]),
        bgcolor=ft.Colors.WHITE, padding=20, border_radius=15, margin=20
    )
    timeline_section = ft.Container(
        content=ft.Column([ft.Text("시각화 차트 (어제 ~ 내일 72시간 / 일정 블록을 클릭하여 수정하세요)", size=16, weight=ft.FontWeight.BOLD, color=ft.Colors.GREY_700), scrollable_timeline]),
        bgcolor=ft.Colors.WHITE, padding=20, border_radius=15, margin=20
    )
    list_section = ft.Container(
        content=ft.Column([ft.Text("상세 일정 및 완료 처리", size=16, weight=ft.FontWeight.BOLD, color=ft.Colors.GREY_700), task_list_column]),
        padding=20 
    )
    memo_section = ft.Container(
        content=ft.Column([
            ft.Row([ft.Text("실시간 메모장", size=16, weight=ft.FontWeight.BOLD, color=ft.Colors.GREY_700), clear_memo_btn], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            memo_input
        ]),
        bgcolor=ft.Colors.WHITE, padding=20, border_radius=15, margin=20
    )

    page.add(header_section, input_section, timeline_section, list_section, memo_section)
    update_ui()

# 웹 배포를 위한 설정 유지
ft.run(main)